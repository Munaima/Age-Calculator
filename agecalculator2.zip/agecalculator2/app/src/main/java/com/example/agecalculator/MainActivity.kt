

package com.example.agecalculator

import android.app.DatePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.util.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.button1)
        button.setOnClickListener {view->
            printAge(view)
        }
    }

    private fun printAge(view:View){
        var myCalender = Calendar.getInstance()
        var year=myCalender.get(Calendar.YEAR)
        var month = myCalender.get(Calendar.MONTH)
        var day = myCalender.get(Calendar.DAY_OF_MONTH)
        var result=findViewById<TextView>(R.id.result)


        DatePickerDialog(this
            ,DatePickerDialog.OnDateSetListener{
                    view,year,month,day->
                val selectedDate="$day/${month+1}/$year"

                var textView1=findViewById<TextView>(R.id.textView1)
                textView1.text= selectedDate




                var dob=Calendar.getInstance()
                dob.set(year,month,day)
//               21            20/03/2021                            24/03/2000
                var age =  myCalender.get(Calendar.YEAR) - dob.get(Calendar.YEAR)
                if(myCalender.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR))
                {
                    age--
                }

                var textView2 = findViewById<TextView>(R.id.textView2)
                textView2.text="You are $age year old."

                if(age == 0){
                    result.text = "You are an infant!"

                }
                else if(age > 0 && age <=3) {
                    result.text = "You are a Toddler!"
                }
                else if(age > 3 && age <=12) {
                    result.text = "You are a Child!"
                }
                else if(age > 12 && age <=19) {
                    result.text = "You are a Teen!"
                }
                else if(age > 19 && age <=60) {
                    result.text = "You are an Adult!"
                }
                else{
                    result.text = "You are a Senior Citizen!"
                }




            }
            ,year
            ,month
            ,day).show()



    }

}